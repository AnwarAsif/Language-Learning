# config.py
config = {
    "api_key": "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"
}
