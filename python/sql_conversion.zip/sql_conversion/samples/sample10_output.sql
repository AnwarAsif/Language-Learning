-- Output: Databricks SQL limit
SELECT employee_id, name
FROM employees
LIMIT 10;
