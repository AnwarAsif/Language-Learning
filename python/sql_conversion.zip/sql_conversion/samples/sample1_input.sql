-- date and time fundtions oracle 
SELECT TO_DATE('2023-08-28', 'YYYY-MM-DD') AS formatted_date, SYSDATE AS current_date FROM DUAL;
