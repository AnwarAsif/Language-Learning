-- date and time sample output to databricks
SELECT CAST('2023-08-28' AS DATE) AS formatted_date, current_date() AS current_date;
