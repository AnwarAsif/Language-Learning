-- oracle string function sample 
SELECT SUBSTR('Databricks', 1, 5) AS substring, INSTR('Databricks', 'b') AS position FROM DUAL;
