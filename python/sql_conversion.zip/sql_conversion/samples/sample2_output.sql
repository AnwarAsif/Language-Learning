-- string functions output to databricks
SELECT substring('Databricks', 1, 5) AS substring, instr('Databricks', 'b') AS position;
