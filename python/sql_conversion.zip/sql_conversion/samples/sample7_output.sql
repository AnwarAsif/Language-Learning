-- Output: Databricks SQL temporary tables 
CREATE TEMPORARY VIEW temp_employees AS
SELECT 1 AS employee_id, 'John' AS name;
