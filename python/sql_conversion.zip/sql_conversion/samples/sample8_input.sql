-- Input: Oracle SQL concatenation 
SELECT first_name || ' ' || last_name AS full_name
FROM employees;
